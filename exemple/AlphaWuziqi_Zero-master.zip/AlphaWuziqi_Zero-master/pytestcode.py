import numpy as np

# class A(object):
#     def __init__(self,a):
#         self.a = a
#         pass
#
#     def prin(self):
#         print(self.a)
#         pass
#
#     pass
# A1 = A(1)
# A2 = A(2)
# # A1.prin()
# #
# # a = 3
# #
# # A1.prin()
# tt = []
# tt.append(A1)
# tt.append(A2)
#
# # a = np.zeros(3)-1
# # b = np.zeros(3)-8
# # t = a/b
# print(tt)

# state1 = np.array([1,2,3])
# state2 = np.array([1,2,3])
# print(state1)x
#
# state1=[]
# print(state1)
# if (state1==state2).all():
#     print('结点未更新')
# else:
#     print('结点已更新')

# a =[11,2,3,4]
# t = [item+index for item,index in a]
# print(t)

# x = input('请输入选择的模式：')
# print(x)
# import numpy as np
# a = np.array([[1,2,3],[4,5,6],[7,8,9]])
# b = np.array([[0,0,0]])
# c = np.r_[a,b]
# d = np.c_[a,b.T]
# print(c)
# print (d)
# a = [1,2,3]
# b = a[2]
# a[2]=0
# print(b)

# !/usr/bin/python
# -*- coding: UTF-8 -*-

# coding=utf-8

if __name__ == '__main__':

    for i, j in enumerate([10, 12]):
        print(i,j)
