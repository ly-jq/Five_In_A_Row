# AlphaWuziqi_Zero
Use the Alpha_go zero algorithm to Train gobang

RL(强化学习)  Alphago_Zero 算法 用于五子棋的实现
